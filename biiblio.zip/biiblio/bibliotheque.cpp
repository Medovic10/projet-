#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Structure pour l'utilisateur
typedef struct {
    char nom[10];
    char prenom[10];
    char login[30];
    char motdepasse[30];
} utilisateur;

// Structure du livre
typedef struct {
    char id[10];
    char titre[50];
    char auteur[50];
    char description[1000];
    float prix;
    utilisateur nomutil;
    char categorie[50];
    char disponibilite[3];
} livre;
// Proc�dure pour afficher les biens de l'agence
void afficherlivre(livre *liv, int nombrelivre) {
    printf("Liste des livres de l'agence :\n");
    int i;
    for ( i = 0; i < nombrelivre; i++) {
        
        printf("ID : %s\n", (liv+ i)->id);
        printf("le titre : %s\n", (liv + i)->titre);
        printf("Auteur : %s\n", (liv + i)->auteur);
        printf("Prix : %.2f\n", (liv + i)->prix);
        printf("description : %s\n", (liv + i)->description);
        printf("categorie : %s\n", (liv + i)->categorie);
        printf("diponibilite : %s\n", (liv + i)->disponibilite);
        if((liv + i)->disponibilite=="oui" ){
        	printf("utilisateur :\n");
            printf("   nom : %s\n", (liv + i)->nomutil.nom);
            printf("   prenom: %s\n", (liv + i)->nomutil.prenom);
            printf("   login : %s\n", (liv + i)->nomutil.login);
		}
        
    
        printf("----------------\n");
    }
    
}


int compterLignes() {
    FILE *fichier;
    int nombreLignes = 0;
    char ligne[100]; // En supposant que la longueur maximale d'une ligne est de 100 caract�res
    
    fichier = fopen("barca.csv", "r");
    if (fichier) {
        while (fgets(ligne, sizeof(ligne), fichier) != NULL) {
            nombreLignes++;
        }
        fclose(fichier);
    }
    return nombreLignes;
}


void write_Data (livre *liv,int n){
int i;
	int nombrelivre;
FILE *f;
f=fopen("barca.csv","a");
	printf("Donner le nombre des livre de la bibliotheque : ");
    scanf("%d", &nombrelivre);
   liv = (livre *)malloc(nombrelivre * sizeof(livre));
   
   
if(f){
	for(i=0;i<nombrelivre;i++){
	

        
        printf("ID : ");
        scanf("%s", (liv + i)->id);
        printf("titre : ");
        scanf("%s", (liv + i)->titre);
        printf("Auteur : ");
        scanf("%s", (liv+ i)->auteur);
        printf("Prix : ");
        scanf("%f", &(liv + i)->prix);
        printf("description : ");
        scanf("%s", (liv+ i)->description);
        printf("categorie  : ");
        scanf("%s", (liv+ i)->categorie);
        printf("diponibilite (oui/non) : ");
        scanf("%s", (liv + i)->disponibilite);
        
        printf("utilisateur  :\n ");
        printf("Nom  :");
        scanf("%s", (liv + i)->nomutil.nom);
        printf("prenom : ");
        scanf("%s", (liv + i)->nomutil.prenom);
        printf("login : ");
        scanf("%s", (liv + i)->nomutil.login);
        
	fprintf(f,"%s,%s,%s,%f,%s,%s,%s,%s,%s,%s\n",(liv + i)->id,(liv + i)->auteur,(liv+ i)->auteur,(liv + i)->prix,(liv+ i)->description,(liv+ i)->categorie,(liv + i)->nomutil.nom,(liv + i)->nomutil.prenom,(liv + i)->nomutil.login);	
	}
	fclose(f);
}	
	
}
void ajouterDansCSV(const char *nomFichier, livre *liv, int n) {
		int nombrelivre;
		int i;
    FILE *f = fopen(nomFichier, "a");
    printf("Donner le nombre des livre de la bibliotheque : ");
    scanf("%d", &nombrelivre);
   liv = (livre *)malloc(nombrelivre * sizeof(livre));
if(f){
	for(i=0;i<nombrelivre;i++){
	

        
        printf("ID : ");
        scanf("%s", (liv + i)->id);
        printf("titre : ");
        scanf("%s", (liv + i)->titre);
        printf("Auteur : ");
        scanf("%s", (liv+ i)->auteur);
        printf("Prix : ");
        scanf("%f", &(liv + i)->prix);
        printf("description : ");
        scanf("%s", (liv+ i)->description);
        printf("categorie  : ");
        scanf("%s", (liv+ i)->categorie);
        printf("diponibilite (oui/non) : ");
        scanf("%s", (liv + i)->disponibilite);
        
        printf("utilisateur  :\n ");
        printf("Nom  :");
        scanf("%s", (liv + i)->nomutil.nom);
        printf("prenom : ");
        scanf("%s", (liv + i)->nomutil.prenom);
        printf("login : ");
        scanf("%s", (liv + i)->nomutil.login);
	fprintf(f,"%s,%s,%s,%f,%s,%s,%s,%s,%s,%s\n",(liv + i)->id,(liv + i)->auteur,(liv+ i)->auteur,(liv + i)->prix,(liv+ i)->description,(liv+ i)->categorie,(liv + i)->nomutil.nom,(liv + i)->nomutil.prenom,(liv + i)->nomutil.login);	
	}}
	fclose(f);
	
    if (f) {
        for (int i = 0; i <nombrelivre; i++) {
            fprintf(f, "%s,%s,%s,%.2f,%s,%s,%s,%s,%s,%s\n",
                    (liv + i)->id, (liv + i)->titre, (liv + i)->auteur,
                    (liv + i)->prix, (liv + i)->description, (liv + i)->categorie,
                    (liv + i)->disponibilite, (liv + i)->nomutil.nom,
                    (liv + i)->nomutil.prenom, (liv + i)->nomutil.login);
        }
        fclose(f); 
    } else {
        printf("Erreur : Impossible d'ouvrir le fichier %s\n", nomFichier);
    }
}

void afficherCSV(const char *nomFichier) {
    FILE *fichier = fopen(nomFichier, "r");
    if (fichier != NULL) {
        char ligne[100]; // Suppose une longueur maximale de ligne de 100 caract�res
        while (fgets(ligne, sizeof(ligne), fichier) != NULL) {
            printf("%s", ligne);
        }
        fclose(fichier);
    } else {
        printf("Erreur : Impossible d'ouvrir le fichier %s\n", nomFichier);
    }
}

	







int main(){
	system("color 70");
	livre*liv;
    char categorie[10];
    char nom[10];
    char prenom[10];
    char login[30];
    char titre[50];
    char auteur[50];
	int a,b,position,prix;
	int nombrelivre;
	int maxlivre= 0;
	livre livreAjoute;
	int n;
	const char *nomFichier = "barca.csv";
    FILE *f;


f=fopen("barca.csv","a");
fprintf(f,"ID;titre;Auteur;prix;description;categorie;disponibilite;Nom;prenom;login\n");	
fclose(f);	

   liv = (livre *)malloc(nombrelivre * sizeof(livre));
  
	
f=fopen("barca.csv","a");
	printf("Donner le nombre des livre de la bibliotheque : ");
    scanf("%d", &nombrelivre);
   liv = (livre *)malloc(nombrelivre * sizeof(livre));
   
   
if(f){
	for( int i=0;i<nombrelivre;i++){
        printf("ID : ");
        scanf("%s", (liv + i)->id);
        printf("titre : ");
        scanf("%s", (liv + i)->titre);
        printf("Auteur : ");
        scanf("%s", (liv+ i)->auteur);
        printf("Prix : ");
        scanf("%f", &(liv + i)->prix);
        printf("description : ");
        scanf("%s", (liv+ i)->description);
        printf("categorie  : ");
        scanf("%s", (liv+ i)->categorie);
        printf("diponibilite (oui/non) : ");
        scanf("%s", (liv + i)->disponibilite);
        
        printf("utilisateur  :\n ");
        printf("Nom  :");
        scanf("%s", (liv + i)->nomutil.nom);
        printf("prenom : ");
        scanf("%s", (liv + i)->nomutil.prenom);
        printf("login : ");
        scanf("%s", (liv + i)->nomutil.login);
        
	fprintf(f,"%s;%s;%s;%f;%s;%s;%s;%s;%s;%s;%s\n",(liv + i)->id,(liv + i)->titre,(liv+ i)->auteur,(liv + i)->prix,(liv+ i)->description,(liv+ i)->categorie,(liv + i)->disponibilite,(liv + i)->nomutil.nom,(liv + i)->nomutil.prenom,(liv + i)->nomutil.login);	
	}
	
	fclose(f);
}	

	red:
	printf("\n");
    printf("\n");
    printf("\n");	
	printf("*****************************************   MENU GESTION BIBLOTHEQUE RAHMA   ******************************************* \n\n");
	printf("                                      (1)Afficher les livres de la bibliotheque \n");             
	printf("                                      (2)Afficher les livre les plus populaires \n");
	printf("                                      (3)recherche d'un livre \n");
	printf("                                      (4)Ajouter un livre \n");
	printf("                                      (5)Supprimer un livre \n");
	printf("                                      (6)quitter l'application \n\n");
	printf("************************************************************************************************************************\n\n");
	scanf("%d",&a);
	
	switch (a){
		case 1:afficherCSV( nomFichier);goto red;
		case 2:
		

		case 3:
	    printf("\n");
        printf("\n");
        printf("\n");
		printf("(1)par le titre\n");
	    printf("(2)par l'auteur \n");
	    printf("(3)par une categorie\n");
	    scanf("%d",&b);
	    switch (b){
	    	
	     case 1:
		 
         printf("Donner le titre:\n");
         scanf("%s",&titre);
    
        for (int i = 0; i < nombrelivre; i++) {
             if (strcmp((liv + i)->titre, titre) == 0 ){
        printf("ID : %s\n", (liv+ i)->id);
        printf("Auteur : %s\n", (liv + i)->auteur);
        printf("Prix : %.2f\n", (liv + i)->prix);
        printf("description : %s\n", (liv + i)->description);
        printf("categorie : %s\n", (liv + i)->categorie);
        printf("diponibilite : %s\n", (liv + i)->disponibilite);
        if((liv + i)->disponibilite=="oui" ){
        	printf("utilisateur :\n");
            printf("   nom : %s\n", (liv + i)->nomutil.nom);
            printf("   prenom: %s\n", (liv + i)->nomutil.prenom);
            printf("   login : %s\n", (liv + i)->nomutil.login);}
                 
                }
            }goto red;

		 case 2:
		 	printf("Donner l'auteur':\n");
         scanf("%s",&auteur);
    
        for (int i = 0; i < nombrelivre; i++) {
             if (strcmp((liv + i)->auteur, auteur) == 0 ){
        printf("ID : %s\n", (liv+ i)->id);
        printf("titre : %s\n", (liv + i)->titre);
        printf("Prix : %.2f\n", (liv + i)->prix);
        printf("description : %s\n", (liv + i)->description);
        printf("categorie : %s\n", (liv + i)->categorie);
        printf("diponibilite : %s\n", (liv + i)->disponibilite);
        if((liv + i)->disponibilite=="oui" ){
        	printf("utilisateur :\n");
            printf("   nom : %s\n", (liv + i)->nomutil.nom);
            printf("   prenom: %s\n", (liv + i)->nomutil.prenom);
            printf("   login : %s\n", (liv + i)->nomutil.login);}
                 
                }
            }goto red;

        
        


		 case 3:
    printf("Donner une categorie");
    scanf("%s",&categorie);
     for (int i = 0; i < nombrelivre; i++) {
        if (strcmp((liv + i)->categorie, categorie) == 0 ){
        printf("ID : %s\n", (liv+ i)->id);
        printf("le titre : %s\n", (liv + i)->titre);
        printf("Auteur : %s\n", (liv + i)->auteur);
        printf("Prix : %.2f\n", (liv + i)->prix);
        printf("description : %s\n", (liv + i)->description);
        printf("diponibilite : %s\n", (liv + i)->disponibilite);
        if((liv + i)->disponibilite=="oui" ){
        	printf("utilisateur :\n");
            printf("   nom : %s\n", (liv + i)->nomutil.nom);
            printf("   prenom: %s\n", (liv + i)->nomutil.prenom);
            printf("   login : %s\n", (liv + i)->nomutil.login);
        }
    }
	
		 
	    	
	    	
	}
	   	
	}
			
		case 4:
		printf("\n");
        printf("\n");
        printf("\n");	
		printf("(1)Au debut de la liste \n");
	    printf("(2)A la fin de la liste \n");
	    printf("(3)A une posision donne\n");
	    scanf("%d",&b);
	    switch (b){
	    	
	     case 1:
	     	printf("donner le livre a ajouter:");
	     	f=fopen("barca.csv","a");
	     	
        printf("ID : ");
        scanf("%s", livreAjoute.id);
        printf("titre : ");
        scanf("%s", livreAjoute.titre);
        printf("Auteur : ");
        scanf("%s",livreAjoute.auteur);
        printf("Prix : ");
        scanf("%f", &livreAjoute.prix);
        printf("description : ");
        scanf("%s", livreAjoute.description);
        printf("categorie  : ");
        scanf("%s", livreAjoute.categorie);
        printf("diponibilite (oui/non) : ");
        scanf("%s", livreAjoute.disponibilite);
        
        printf("utilisateur  :\n ");
        printf("Nom  :");
        scanf("%s", livreAjoute.nomutil.nom);
        printf("prenom : ");
        scanf("%s",livreAjoute.nomutil.prenom);
        printf("login : ");
        scanf("%s",livreAjoute.nomutil.login);
	     	(nombrelivre)=(nombrelivre+1);
                 liv = (livre *)realloc( liv, nombrelivre * sizeof(livre));

                      for (int i = nombrelivre - 1; i > 0; i--) {
                         *((liv) + i) = *((liv) + i - 1);}
                  *((liv) + 0) =livreAjoute;
					
            
			fprintf(f,"%s;%s;%s;%f;%s;%s;%s;%s;%s;%s;%s\n",livreAjoute.id,livreAjoute.titre,livreAjoute.auteur,livreAjoute.prix,livreAjoute.description,livreAjoute.categorie,livreAjoute.disponibilite,livreAjoute.nomutil.nom,livreAjoute.nomutil.prenom,livreAjoute.nomutil.login);
			fclose(f);
			
			
			goto red;

	
		 case 2:
		  	printf("donner le livre a ajouter:");
	     		f=fopen("barca.csv","a");
        printf("ID : ");
        scanf("%s", livreAjoute.id);
        printf("titre : ");
        scanf("%s", livreAjoute.titre);
        printf("Auteur : ");
        scanf("%s",livreAjoute.auteur);
        printf("Prix : ");
        scanf("%f", &livreAjoute.prix);
        printf("description : ");
        scanf("%s", livreAjoute.description);
        printf("categorie  : ");
        scanf("%s", livreAjoute.categorie);
        printf("diponibilite (oui/non) : ");
        scanf("%s", livreAjoute.disponibilite);
        
        printf("utilisateur  :\n ");
        printf("Nom  :");
        scanf("%s", livreAjoute.nomutil.nom);
        printf("prenom : ");
        scanf("%s",livreAjoute.nomutil.prenom);
        printf("login : ");
        scanf("%s",livreAjoute.nomutil.login);
        
	     	(nombrelivre)=(nombrelivre+1);
                   liv = (livre*)realloc(liv, nombrelivre * sizeof(livre));
                   *((liv+nombrelivre -1)) = livreAjoute;
				   	fprintf(f,"%s;%s;%s;%f;%s;%s;%s;%s;%s;%s;%s\n",livreAjoute.id,livreAjoute.titre,livreAjoute.auteur,livreAjoute.prix,livreAjoute.description,livreAjoute.categorie,livreAjoute.disponibilite,livreAjoute.nomutil.nom,livreAjoute.nomutil.prenom,livreAjoute.nomutil.login);
			fclose(f);
				   goto red;

		 case 3:
		 	printf("donner la position:");
		 	scanf("%d",&position);
		 		f=fopen("barca.csv","a");
		 	
		 	printf("donner le livre a ajouter:");
        printf("ID : ");
        scanf("%s", livreAjoute.id);
        printf("titre : ");
        scanf("%s", livreAjoute.titre);
        printf("Auteur : ");
        scanf("%s",livreAjoute.auteur);
        printf("Prix : ");
        scanf("%f", &livreAjoute.prix);
        printf("description : ");
        scanf("%s", livreAjoute.description);
        printf("categorie  : ");
        scanf("%s", livreAjoute.categorie);
        printf("diponibilite (oui/non) : ");
        scanf("%s", livreAjoute.disponibilite);
        printf("utilisateur  :\n ");
        printf("Nom  :");
        scanf("%s", livreAjoute.nomutil.nom);
        printf("prenom : ");
        scanf("%s",livreAjoute.nomutil.prenom);
        printf("login : ");
        scanf("%s",livreAjoute.nomutil.login);
       
    position-1;
    nombrelivre ++;;
    liv = (livre *)realloc(liv, nombrelivre * sizeof(livre));

    for (int i = nombrelivre - 1; i > position; i--) {
        *((liv) + i) = *((liv) + i - 1);
    }

    *((liv) + position) = livreAjoute;
	
	
		fprintf(f,"%s;%s;%s;%f;%s;%s;%s;%s;%s;%s;%s\n",livreAjoute.id,livreAjoute.titre,livreAjoute.auteur,livreAjoute.prix,livreAjoute.description,livreAjoute.categorie,livreAjoute.disponibilite,livreAjoute.nomutil.nom,livreAjoute.nomutil.prenom,livreAjoute.nomutil.login);
			fclose(f);
	goto red;
}
    
		 

	    
		
			
		case 5:
		printf("\n");
        printf("\n");
        printf("\n");
		printf("(1)Au debut de la liste \n");
	    printf("(2)A la fin de la liste \n");
	    printf("(3)En une position donn�e \n");
	    printf("(4)Par prix \n");
	    printf("(5)Par login \n");
	    printf("(6)D'un titre \n");
	    scanf("%d",&b);
		switch (b){
	    	
	     case 1:
    if (nombrelivre > 0) {
        for (int i = 0; i < nombrelivre - 1; i++) {
            *((liv) + i) = *((liv) + i + 1);
        }

        nombrelivre =nombrelivre-1;
        liv = (livre *)realloc(liv, nombrelivre * sizeof(livre));
    } else {
        printf("Il n'y a pas de livre a supprimer.\n");
    }goto red;

		 case 2:
		 	
    if (nombrelivre > 0) {
        nombrelivre -= 1;
        liv = (livre *)realloc(liv, nombrelivre * sizeof(livre));
    } else {
        printf("Il n'y a pas de livre a supprimer.\n");
    }goto red;
		 case 3:
		 	printf("donner la position:");
		 	scanf("%d",&position);
		 position--;
    if (nombrelivre > 0 && position >= 0 && position < nombrelivre) {
        for (int i = position; i < nombrelivre - 1; i++) {
            *((liv) + i) = *((liv) + i + 1);
        }

         nombrelivre =nombrelivre-1;
        liv= (livre*)realloc(liv, nombrelivre * sizeof(livre));
    } else {
        printf("La position de suppression n'exist pas.\n");
    }goto red;
	
	     case 4:
	     	printf("donner le prix :");
	     	scanf("%d",&prix);
	     	
     position = -1;
    for (int i = 0; i < nombrelivre; i++) {
        if (((liv) + i)->prix == prix) {
            position = i;
            break;
        }
    }

    if (position != -1) {
        if (nombrelivre > 0 && position >= 0 && position < nombrelivre) {
        for (int i = position; i < nombrelivre - 1; i++) {
            *((liv) + i) = *((liv) + i + 1);
        }

         nombrelivre =nombrelivre-1;
        liv= (livre *)realloc(liv, nombrelivre * sizeof(livre));
    } 
    } else {
        printf("Aucun livre trouve avec ce prix .\n");
    }goto red;

		 case 5:
		 	printf("donner le login");
		 	scanf("%s",&login);
    position = -1;
    for (int i = 0; i < nombrelivre; i++) {
        if (strcmp(((liv) + i)->nomutil.login,login) == 0) {
            position = i;
            break;
        }
    }

    if (position != -1) {
       if (nombrelivre > 0 && position >= 0 && position < nombrelivre) {
        for (int i = position; i < nombrelivre - 1; i++) {
            *((liv) + i) = *((liv) + i + 1);
        }

         nombrelivre =nombrelivre-1;
        liv = (livre *)realloc(liv, nombrelivre * sizeof(livre));
    } 
    } else {
        printf("Aucun livre trouve avec ce login.\n");
    }goto red;

		 	
		 case 6:
		 printf("dooner le titre :");
		 scanf("%s",&titre);
		 
		  position = -1;
  for (int i = 0; i < nombrelivre; i++) {
    if (strcmp((liv + i)->titre, titre) == 0) {
      position = i;
      break;
	  }
	  }
	  if (position != -1) {
       if (nombrelivre > 0 && position >= 0 && position < nombrelivre) {
        for (int i = position; i < nombrelivre - 1; i++) {
            *((liv) + i) = *((liv) + i + 1);
        }

         nombrelivre =nombrelivre-1;
        liv = (livre *)realloc(liv, nombrelivre * sizeof(livre));
    } 
    } else {
        printf("Aucun livre trouve avec ce titre.\n");
    }goto red;	
		
		break;
	
	}
 case 6:
	  
        free(liv);
        liv = NULL;
    	nombrelivre = 0;
	  goto medo;
    
}


medo:
printf("\n");
printf("\n");
printf("\n");
printf("********************MERCI DE VOTRE VISITE********************");








return 0;	
	
}
